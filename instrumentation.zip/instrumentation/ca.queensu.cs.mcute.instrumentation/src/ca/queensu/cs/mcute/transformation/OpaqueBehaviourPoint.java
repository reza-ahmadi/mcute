package ca.queensu.cs.mcute.transformation;

public enum OpaqueBehaviourPoint {

	OnEntry, OnExit

}
